package com.mindgate.main.contoller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
@RestController
@RequestMapping("myapi")
public class MyFirstController {
	
	//http://localhost:8081/myapi/greet---delete
	@RequestMapping(value="greet",method=RequestMethod.DELETE)
	public String printDeleteMessage() {
		return "hello Worldfrom Spring Boot-Delete";
	}
	//http://localhost:8081/myapi/greet--Put
	@RequestMapping(value="greet",method=RequestMethod.PUT)
	public String printPutMessage() {
		return "hello Worldfrom Spring Boot-put";
	}
	
	//http://localhost:8081/myapi/greet--get
	@RequestMapping(value="greet",method=RequestMethod.GET)
	public String printMessage() {
		return "hello Worldfrom Spring Boot!!";
		
	}
	//http://localhost:8081/myapi/greet-post
	@RequestMapping(value="greet",method=RequestMethod.POST)
	public String printPostMessage() {
		return "hello Worldfrom Spring Boot-post";
	}

}
