package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.domain.Employee;
import com.mindgate.main.repository.EmployeeRepositoryInterface;

@Service
public class EmployeeService  implements EmployeeServiceInterface{
	@Autowired
	private EmployeeRepositoryInterface employeeRepositoryInterface;
	
	public EmployeeService() {
		// TODO Auto-generated constructor stub
		System.out.println("Default constractor is EmployeeService");
	}
	public boolean addNewEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeeRepositoryInterface.addNewEmployee(employee);
	}

	public Employee updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeeRepositoryInterface.updateEmployee(employee) ;
	}

	public boolean deleteEmployee(int employeeId) {
		// TODO Auto-generated method stub
		return employeeRepositoryInterface.deleteEmployee(employeeId);
	}

	public Employee getEmployeeByEmployeeId(int employeeId) {
		// TODO Auto-generated method stub
		return employeeRepositoryInterface.getEmployeeByEmployeeId(employeeId);
	}

	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return employeeRepositoryInterface.getAllEmployee();
	}

}
