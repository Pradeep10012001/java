package com.mindgate.main.domain;

public class Employee {
	private int employeeId;
     private String name;
     private double salary;
     public Employee() {
		// TODO Auto-generated constructor stub
    	 System.out.println("default constractor");
	}
	public Employee(int employeeId, String name, double salary) {
		super();
		System.out.println("parameterized constractor");
		this.employeeId = employeeId;
		this.name = name;
		this.salary = salary;
	}
	public int getEmployeeId() {
		System.out.println("get employee id");
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		System.out.println("'set employee id");
		this.employeeId = employeeId;
	}
	public String getName() {
		System.out.println("get name");
		return name;
	}
	public void setName(String name) {
		System.out.println("set name");
		this.name = name;
	}
	public double getSalary() {
		System.out.println("get salary");
		return salary;
	}
	public void setSalary(double salary) {
		System.out.println("set salary");
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", name=" + name + ", salary=" + salary + "]";
	}
     
}
