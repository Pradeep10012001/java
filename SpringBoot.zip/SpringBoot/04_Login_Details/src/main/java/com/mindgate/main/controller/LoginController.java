package com.mindgate.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindgate.main.domain.LoginDetails;
import com.mindgate.main.service.LoginServiceInterface;

@RestController
@RequestMapping("/loginapi")
public class LoginController {
	@Autowired
	private LoginServiceInterface loginServiceInterface;

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public LoginDetails getLoginDetails(@RequestBody LoginDetails login) {
		return loginServiceInterface.getLoginDetails(login);
	}
	  @RequestMapping(value="employees", method=RequestMethod.GET)
	     public List<LoginDetails> AllEmployee(){
			return loginServiceInterface.AllEmployee();
	    	 
	     }

}
