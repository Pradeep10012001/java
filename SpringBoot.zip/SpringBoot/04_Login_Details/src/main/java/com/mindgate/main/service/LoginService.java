package com.mindgate.main.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.domain.LoginDetails;
import com.mindgate.main.repository.RepositoryInterface;
@Service
public class LoginService implements LoginServiceInterface{
	@Autowired
	private RepositoryInterface repositoryInterface;

	@Override
	public LoginDetails getLoginDetails(LoginDetails login) {
		// TODO Auto-generated method stub
		return repositoryInterface.getLoginDetails(login);
	}

	@Override
	public List<LoginDetails> AllLogin() {
		// TODO Auto-generated method stub
		return repositoryInterface.AllLogin();
	}
	




	

}
