package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.domain.LoginDetails;

public interface RepositoryInterface {
	

	//public LoginDetails getLoginDetails(int loginid, String password);

	public LoginDetails getLoginDetails(LoginDetails login);

	public List<LoginDetails> AllLogin();
}
