package com.mindgate.main.domain;

public class LoginDetails {

	private int loginId;
	private String userName;
	private String passWord;
	private String role;
	public LoginDetails() {
		// TODO Auto-generated constructor stub
	}
	public LoginDetails(int loginId, String userName, String passWord, String role) {
		super();
		this.loginId = loginId;
		this.userName = userName;
		this.passWord = passWord;
		this.role = role;
	}
	public int getLoginId() {
		return loginId;
	}
	public void setLoginId(int loginId) {
		this.loginId = loginId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "LoginDetails [loginId=" + loginId + ", userName=" + userName + ", passWord=" + passWord + ", role="
				+ role + "]";
	}
	
}
