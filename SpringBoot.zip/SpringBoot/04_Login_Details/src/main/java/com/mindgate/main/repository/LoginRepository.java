package com.mindgate.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.domain.LoginDetails;
@Repository
public class LoginRepository  implements RepositoryInterface{

     @Autowired
	private JdbcTemplate jdbcTemplate;
     
     private final static String SELECT_ONE_EMPLOYEE = "select * from logindetails where LOGIN_ID=? and PASSWORD=?";
     private final static String all="select * from  logindetails";
   @Override
	public LoginDetails getLoginDetails(LoginDetails loginDetails) {
		 Object[] parameters = {loginDetails.getLoginId(), loginDetails.getPassWord() };
    	 LoginRowMapper loginRowMapper = new LoginRowMapper();
    	 return jdbcTemplate.queryForObject(SELECT_ONE_EMPLOYEE,loginRowMapper,parameters );
 		
		
	}

@Override
public List<LoginDetails> AllLogin() {
	// TODO Auto-generated method stub
	 LoginRowMapper loginRowMapper = new LoginRowMapper();
	 return (List<LoginDetails>) jdbcTemplate.queryForObject(all,loginRowMapper );
}
     
     


}
