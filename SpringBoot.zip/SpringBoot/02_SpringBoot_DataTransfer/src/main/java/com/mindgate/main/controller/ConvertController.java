package com.mindgate.main.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("convertapi")
public class ConvertController {

	@RequestMapping(value="/upper/{name}",method=RequestMethod.GET)
	public String upper(@PathVariable String name) {
		return name.toUpperCase();
		
	}
	@RequestMapping(value="/lower/{name}",method=RequestMethod.GET)
	public String lower(@PathVariable String name) {
		return name.toLowerCase();
		
	}
}
